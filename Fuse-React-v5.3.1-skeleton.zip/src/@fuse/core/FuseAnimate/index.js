export { default } from './FuseAnimate';
