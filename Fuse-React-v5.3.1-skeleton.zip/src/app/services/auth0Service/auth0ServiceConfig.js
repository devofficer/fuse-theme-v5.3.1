const AUTH_CONFIG = {
	// domain     : "YOUR_DOMAIN",
	// clientId   : "YOUR_CLIENT_ID",
	// callbackUrl: "YOUR_DOMAIN/callback"
};

export default AUTH_CONFIG;
