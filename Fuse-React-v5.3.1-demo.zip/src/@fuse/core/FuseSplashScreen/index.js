export { default } from './FuseSplashScreen';
